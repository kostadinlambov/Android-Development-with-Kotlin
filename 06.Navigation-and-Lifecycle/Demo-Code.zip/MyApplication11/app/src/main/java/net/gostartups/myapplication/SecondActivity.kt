package net.gostartups.myapplication

import android.app.Activity
import android.os.Bundle
import net.gostartups.myapplication.databinding.ActivitySecondBinding

class SecondActivity : Activity() {

    lateinit var binding: ActivitySecondBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySecondBinding.inflate(layoutInflater)

        setContentView(binding.root)

        val title = intent.extras?.getString("title") ?: "Default Title"
        binding.tvTitle.text = title

        binding.btnPreviousActivity.setOnClickListener {
//            val intent = Intent(this, MainActivity::class.java)
//            startActivity(intent)
            finish()
        }
    }
}